#include "protocolo_fsm.h"
#include <string.h>
/* Tabela de fun��es de estado */
static FuncaoEstado tabela_estados[NUM_ESTADOS] = {
    estado_idle,
    estado_aguarda_qtd,
    estado_process_dados,
    estado_aguarda_chk,
    estado_completa,
    estado_erro
};

void maquina_init(MaquinaProtocolo *maq) {
    maq->estado_atual = ESTADO_IDLE;
    maq->qtd_dados_esperada = 0;
    maq->indice_dados = 0;
    maq->checksum_calculado = 0;
    maq->checksum_recebido = 0;
    maq->pacote_completo = 0;
    memset(maq->dados_recebidos, 0, sizeof(maq->dados_recebidos));
}

EventoProtocolo classificar_evento(uint8_t byte, EstadoProtocolo estado_atual) {
    switch (estado_atual) {
        case ESTADO_IDLE:
            return (byte == 0x02) ? EV_STX : EV_OUTRO;

        case ESTADO_COMPLETA:
            return (byte == 0x03) ? EV_ETX : EV_OUTRO;

        default:
            if (byte == 0x02) return EV_STX;
            if (byte == 0x03) return EV_ETX;
            return EV_OUTRO;
    }
}

EstadoProtocolo maquina_processa_byte(MaquinaProtocolo *maq, uint8_t byte) {
    /* Chama a fun��o de estado apropriada atrav�s da tabela */
    maq->estado_atual = tabela_estados[maq->estado_atual](maq, byte);
    return maq->estado_atual;
}

/* Implementa��o das fun��es de estado */
EstadoProtocolo estado_idle(MaquinaProtocolo *maq, uint8_t byte) {
    if (byte == 0x02) { // STX
        maq->checksum_calculado = byte;
        return ESTADO_AGUARDA_QTD;
    }
    return ESTADO_IDLE;
}

EstadoProtocolo estado_aguarda_qtd(MaquinaProtocolo *maq, uint8_t byte) {
    maq->qtd_dados_esperada = byte;
    maq->checksum_calculado ^= byte;
    maq->indice_dados = 0;
    return ESTADO_PROCESS_DADOS;
}

EstadoProtocolo estado_process_dados(MaquinaProtocolo *maq, uint8_t byte) {
    if (maq->indice_dados < maq->qtd_dados_esperada) {
        maq->dados_recebidos[maq->indice_dados++] = byte;
        maq->checksum_calculado ^= byte;

        if (maq->indice_dados == maq->qtd_dados_esperada) {
            return ESTADO_AGUARDA_CHK;
        }
        return ESTADO_PROCESS_DADOS;
    }
    return ESTADO_ERRO;
}

EstadoProtocolo estado_aguarda_chk(MaquinaProtocolo *maq, uint8_t byte) {
    maq->checksum_recebido = byte;
    return ESTADO_COMPLETA;
}

EstadoProtocolo estado_completa(MaquinaProtocolo *maq, uint8_t byte) {
    if (byte == 0x03) { // ETX
        if (maq->checksum_calculado == maq->checksum_recebido) {
            maq->pacote_completo = 1;
        }
        // Sempre volta para IDLE, independente do checksum
        return ESTADO_IDLE;
    }
    return ESTADO_ERRO;
}

EstadoProtocolo estado_erro(MaquinaProtocolo *maq, uint8_t byte) {
    if (byte == 0x02) { // STX para recupera��o
        maquina_init(maq);
        maq->checksum_calculado = byte;
        return ESTADO_AGUARDA_QTD;
    }
    return ESTADO_ERRO;
}
