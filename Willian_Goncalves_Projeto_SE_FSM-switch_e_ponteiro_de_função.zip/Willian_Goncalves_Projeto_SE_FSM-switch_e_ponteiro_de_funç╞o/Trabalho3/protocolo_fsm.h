#ifndef PROTOCOLO_FSM_H
#define PROTOCOLO_FSM_H

#include <stdint.h>

/* Estados da FSM */
typedef enum {
    ESTADO_IDLE,
    ESTADO_AGUARDA_QTD,
    ESTADO_PROCESS_DADOS,
    ESTADO_AGUARDA_CHK,
    ESTADO_COMPLETA,
    ESTADO_ERRO,
    NUM_ESTADOS
} EstadoProtocolo;

/* Eventos da FSM */
typedef enum {
    EV_STX,          // Recebeu STX (0x02)
    EV_QTD,          // Recebeu QTD_DADOS
    EV_DADO,         // Recebeu byte de dados
    EV_CHK,          // Recebeu CHK
    EV_ETX,          // Recebeu ETX (0x03)
    EV_OUTRO,        // Recebeu outro byte
    NUM_EVENTOS
} EventoProtocolo;

/* Estrutura do protocolo */
typedef struct {
    EstadoProtocolo estado_atual;
    uint8_t qtd_dados_esperada;
    uint8_t dados_recebidos[256];
    uint8_t indice_dados;
    uint8_t checksum_calculado;
    uint8_t checksum_recebido;
    uint8_t pacote_completo;
} MaquinaProtocolo;

/* Tipo ponteiro para fun��o de estado */
typedef EstadoProtocolo (*FuncaoEstado)(MaquinaProtocolo*, uint8_t);

/* Prot�tipos */
void maquina_init(MaquinaProtocolo *maq);
EventoProtocolo classificar_evento(uint8_t byte, EstadoProtocolo estado_atual);
EstadoProtocolo maquina_processa_byte(MaquinaProtocolo *maq, uint8_t byte);

/* Fun��es de estado (ser�o implementadas via tabela) */
EstadoProtocolo estado_idle(MaquinaProtocolo *maq, uint8_t byte);
EstadoProtocolo estado_aguarda_qtd(MaquinaProtocolo *maq, uint8_t byte);
EstadoProtocolo estado_process_dados(MaquinaProtocolo *maq, uint8_t byte);
EstadoProtocolo estado_aguarda_chk(MaquinaProtocolo *maq, uint8_t byte);
EstadoProtocolo estado_completa(MaquinaProtocolo *maq, uint8_t byte);
EstadoProtocolo estado_erro(MaquinaProtocolo *maq, uint8_t byte);

#endif
