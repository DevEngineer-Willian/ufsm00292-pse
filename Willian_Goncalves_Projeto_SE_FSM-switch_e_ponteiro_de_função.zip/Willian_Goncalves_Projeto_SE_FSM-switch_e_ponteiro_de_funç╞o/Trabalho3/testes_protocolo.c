#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "protocolo_fsm.h"

/* Macros de testes TDD */
#define verifica(mensagem, teste) do { if (!(teste)) return mensagem; } while (0)
#define executa_teste(teste) do { char *mensagem = teste(); testes_executados++; \
                                if (mensagem) return mensagem; else printf(" Teste %d PASSOU: %s\n", testes_executados, #teste); } while (0)

int testes_executados = 0;

/* Função para demonstrar um pacote completo */
static void demonstrar_pacote_exemplo(void) {
    printf("\nEXEMPLO DE PACOTE COMPLETO:\n");
    printf("Enviando pacote: 02 03 AA BB CC 66 03\n");
    printf("Onde:\n");
    printf("  02 = STX (Start of Transmission)\n");
    printf("  03 = QTD_DADOS (3 bytes de dados)\n");
    printf("  AA = Dado 1\n");
    printf("  BB = Dado 2\n");
    printf("  CC = Dado 3\n");

    // Cálculo CORRETO do checksum: STX ^ QTD ^ DADO1 ^ DADO2 ^ DADO3
    uint8_t checksum_calculado = 0x02 ^ 0x03 ^ 0xAA ^ 0xBB ^ 0xCC;
    printf("  66 = CHK (Checksum: 02 ^ 03 ^ AA ^ BB ^ CC = %02X)\n", checksum_calculado);
    printf("  03 = ETX (End of Transmission)\n");

    // Demonstração prática do pacote
    MaquinaProtocolo maq;
    maquina_init(&maq);

    printf("\nProcessando pacote exemplo...\n");

    // Processa cada byte do pacote
    uint8_t pacote[] = {0x02, 0x03, 0xAA, 0xBB, 0xCC, checksum_calculado, 0x03};
    const char *nomes[] = {"STX", "QTD", "DADO1", "DADO2", "DADO3", "CHK", "ETX"};

    for (int i = 0; i < 7; i++) {
        EstadoProtocolo estado_anterior = maq.estado_atual;
        maquina_processa_byte(&maq, pacote[i]);

        printf("  Byte %02X (%s): Estado %d -> %d\n",
               pacote[i], nomes[i], estado_anterior, maq.estado_atual);
    }

    if (maq.pacote_completo) {
        printf("\n Pacote processado com SUCESSO!\n");
        printf("  Dados recebidos: ");
        for (int i = 0; i < maq.qtd_dados_esperada; i++) {
            printf("%02X ", maq.dados_recebidos[i]);
        }
        printf("(%d bytes)\n", maq.qtd_dados_esperada);
    } else {
        printf("\n✗ Pacote com ERRO!\n");
    }
    printf("==================================================\n");
}

/* Testes unitários */
static char *teste_classifica_evento_stx(void) {
    verifica("STX deve ser classificado como EV_STX",
             classificar_evento(0x02, ESTADO_IDLE) == EV_STX);
    return 0;
}

static char *teste_classifica_evento_etx(void) {
    verifica("ETX deve ser classificado como EV_ETX",
             classificar_evento(0x03, ESTADO_COMPLETA) == EV_ETX);
    return 0;
}

static char *teste_idle_para_aguarda_qtd(void) {
    MaquinaProtocolo maq;
    maquina_init(&maq);

    EstadoProtocolo novo_estado = maquina_processa_byte(&maq, 0x02);

    verifica("IDLE + STX deve ir para AGUARDA_QTD",
             novo_estado == ESTADO_AGUARDA_QTD);
    verifica("Estado atual deve ser AGUARDA_QTD",
             maq.estado_atual == ESTADO_AGUARDA_QTD);

    return 0;
}

static char *teste_pacote_completo_valido(void) {
    MaquinaProtocolo maq;
    maquina_init(&maq);

    // Pacote: STX, QTD=2, 0x01, 0x02, CHK, ETX
    uint8_t checksum = 0x02 ^ 0x02 ^ 0x01 ^ 0x02;

    maquina_processa_byte(&maq, 0x02);  // STX
    maquina_processa_byte(&maq, 0x02);  // QTD
    maquina_processa_byte(&maq, 0x01);  // Dado 1
    maquina_processa_byte(&maq, 0x02);  // Dado 2
    maquina_processa_byte(&maq, checksum); // CHK
    maquina_processa_byte(&maq, 0x03);  // ETX

    verifica("Pacote valido deve estar completo",
             maq.pacote_completo == 1);
    verifica("Deve voltar para estado IDLE",
             maq.estado_atual == ESTADO_IDLE);

    return 0;
}

static char *teste_checksum_invalido(void) {
    MaquinaProtocolo maq;
    maquina_init(&maq);

    maquina_processa_byte(&maq, 0x02);  // STX
    maquina_processa_byte(&maq, 0x02);  // QTD
    maquina_processa_byte(&maq, 0x01);  // Dado 1
    maquina_processa_byte(&maq, 0x02);  // Dado 2
    maquina_processa_byte(&maq, 0xFF);  // CHK inválido
    maquina_processa_byte(&maq, 0x03);  // ETX

    verifica("Pacote com checksum invalido não deve estar completo",
             maq.pacote_completo == 0);
    verifica("Deve voltar para estado IDLE mesmo com erro",
             maq.estado_atual == ESTADO_IDLE);

    return 0;
}

static char *teste_recuperacao_erro(void) {
    MaquinaProtocolo maq;
    maquina_init(&maq);

    // Força erro
    maquina_processa_byte(&maq, 0x55); // Byte inválido
    verifica("Byte invalido deve manter em IDLE",
             maq.estado_atual == ESTADO_IDLE);

    // Agora envia pacote válido
    uint8_t checksum = 0x02 ^ 0x01 ^ 0xAB;
    maquina_processa_byte(&maq, 0x02);  // STX
    maquina_processa_byte(&maq, 0x01);  // QTD
    maquina_processa_byte(&maq, 0xAB);  // Dado
    maquina_processa_byte(&maq, checksum); // CHK
    maquina_processa_byte(&maq, 0x03);  // ETX

    verifica("Deve processar pacote valido apos erro",
             maq.pacote_completo == 1);

    return 0;
}

static char *teste_processamento_dados(void) {
    MaquinaProtocolo maq;
    maquina_init(&maq);

    // STX -> QTD=2 -> Dado1 -> Dado2 -> CHK -> ETX
    maquina_processa_byte(&maq, 0x02);  // STX
    maquina_processa_byte(&maq, 0x02);  // QTD
    maquina_processa_byte(&maq, 0xAA);  // Dado 1
    maquina_processa_byte(&maq, 0xBB);  // Dado 2

    verifica("Deve estar em AGUARDA_CHK apos 2 dados",
             maq.estado_atual == ESTADO_AGUARDA_CHK);
    verifica("Dado1 deve ser armazenado",
             maq.dados_recebidos[0] == 0xAA);
    verifica("Dado2 deve ser armazenado",
             maq.dados_recebidos[1] == 0xBB);

    return 0;
}

/* Função principal de testes */
static char *executa_testes(void) {
    printf("==================================================\n");
    printf("PROTOCOLO DE COMUNICACAO - FSM COM PONTEIROS DE FUNCAO\n");
    printf("==================================================\n");
    printf("Formato: | STX | QTD_DADOS | DADOS | CHK | ETX |\n");
    printf("STX: 0x02 (Start of Transmission)\n");
    printf("ETX: 0x03 (End of Transmission)\n");
    printf("CHK: Checksum (XOR de todos os bytes anteriores)\n");
    printf("==================================================\n");

    demonstrar_pacote_exemplo();

    printf("EXECUTANDO TESTES TDD:\n");
    printf("==================================================\n");

    executa_teste(teste_classifica_evento_stx);
    executa_teste(teste_classifica_evento_etx);
    executa_teste(teste_idle_para_aguarda_qtd);
    executa_teste(teste_processamento_dados);
    executa_teste(teste_pacote_completo_valido);
    executa_teste(teste_checksum_invalido);
    executa_teste(teste_recuperacao_erro);

    return 0;
}

int main() {
    char *resultado = executa_testes();

    printf("==================================================\n");
    if (resultado != 0) {
        printf("FALHA: %s\n", resultado);
    } else {
        printf("TODOS OS 7 TESTES PASSARAM!\n");
    }

    printf("Testes executados: %d\n", testes_executados);
    printf("==================================================\n");

    return resultado != 0;
}
